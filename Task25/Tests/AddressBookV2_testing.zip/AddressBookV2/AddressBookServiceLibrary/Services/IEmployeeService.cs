﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AddressBookV2.Services.DBModels;

namespace AddressBookV2.Services
{
    public interface IEmployeeService
    {
        public List<DBEmployee> GetEmployees();

        public Task<DBEmployee> GetEmployee(int id);

        public Task AddEmployee(DBEmployee employee);

        public Task UpdateEmployee(DBEmployee employee);

        public Task DeleteEmployee(DBEmployee employee);

        public bool EmployeeExists(int id);

        public bool IsEmailExists(string email, int? id);

        public bool IsMobileNumberExists(string mobileNumber, int? id);
    }
}
