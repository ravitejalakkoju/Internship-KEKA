﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AddressBookV2.Models;
using AddressBookV2.Data;

namespace AddressBookV2.Pages
{
    public class IndexModel : PageModel
    {
        private readonly AddressBookV2.Data.AddressBookV2Context _context;

        public IndexModel(AddressBookV2.Data.AddressBookV2Context context)
        {
            _context = context;
        }

        public IList<Employee> Employees { get;set; }

        public AddressBookV2.Pages.Employees.EditModel EditModel;

        [BindProperty]
        public Employee Employee { get; set; }

        public async Task OnGetAsync()
        {
            Employees = await _context.Employees.ToListAsync();
        }


        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Employees.Add(Employee);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        public async Task<ActionResult> DisplayDetails(int id)
        {
            Employee = await _context.Employees.FirstOrDefaultAsync(m => m.ID == id);

            return ViewComponent("_details", Employee);
        }
    }
}
