﻿$(document).ready(() => {
    $('#Name').addClass("form-control rounded-0 border-dark");
    $('#Email').addClass("form-control rounded-0 border-dark");
    $('#MobileNumber').addClass("form-control rounded-0 border-dark");
    $('#Landline').addClass("form-control rounded-0 border-dark");
    $('#Website').addClass("form-control rounded-0 border-dark");
    $('#Address').addClass("form-control rounded-0 border-dark");
})