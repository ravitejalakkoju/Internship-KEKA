﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AddressBook.Models;

namespace AddressBook.ViewComponents
{
    public class EmployeeForm: ViewComponent
    {
        readonly List<Employee> Employees;

        public EmployeeForm()
        {
            Employees = Employee.AllEmployees();
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var model = Employees.Where(e => e.ID == 0);
            return await Task.FromResult((IViewComponentResult) View("EmployeeForm", model));
        }
    }
}
