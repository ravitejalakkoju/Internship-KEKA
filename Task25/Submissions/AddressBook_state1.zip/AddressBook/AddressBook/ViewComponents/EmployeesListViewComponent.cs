﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AddressBook.Models;

namespace AddressBook.ViewComponents
{
    public class EmployeesList: ViewComponent
    {
        readonly List<Employee> Employees;
        public EmployeesList()
        {
            Employees = Employee.AllEmployees();    
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var model = Employees;
            return await Task.FromResult((IViewComponentResult)View("EmployeesList", model));
        }
    }
}
