﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AddressBook.Models
{
    public class Employee
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string MobileNumber { get; set; }

        public string Landline { get; set; }

        public string Website { get; set; }

        public string Address { get; set; }

        public static List<Employee> AllEmployees()
        {
            List<Employee> Employees = new List<Employee>();

            Employees.Add(new Employee { ID = Employees.Count, Name = "Chandermani Arora", Email = "chandermani@technovert.com", MobileNumber = "9292929222", Landline = "040301231211", Website = "http://www.technovert.com", Address = "123 now here, Some street, Madhapur, Hyderabad 500033" });
            Employees.Add(new Employee { ID = Employees.Count, Name = "Praveen Battula", Email = "praveen@technovert.com", MobileNumber = "9292929222", Landline = "040301231211", Website = "http://www.technovert.com", Address = "123 now here, Some street, Madhapur, Hyderabad 500033" });

            return Employees;
        }
    }
}
