﻿using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Output
{
	public void ShowMenu(Device[][] devices)
    {
        int serialNum = 1;
        for(int i = 0; i < devices.Length; i++)
        {
            for(int j = 0; j < devices[i].Length; j++)
            {
                Console.WriteLine($"{serialNum++}: {devices[i][j].DeviceName} {j+1} is {devices[i][j].GetStatus()}");
            }
        }
    }

    public void ConfirmMenu(Device device, int deviceNumber)
    {
        Console.WriteLine($"1: Switch {device.DeviceName} {deviceNumber + 1} {(device.GetStatus().Equals("On") ? "Off" : "On")}");
        Console.WriteLine("2. Back");
    }
}
