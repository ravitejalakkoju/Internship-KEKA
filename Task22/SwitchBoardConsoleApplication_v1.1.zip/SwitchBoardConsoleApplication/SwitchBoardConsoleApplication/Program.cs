﻿using System;

namespace SwitchBoardConsoleApplication
{
    class Program
    {
        public enum DeviceEnum
        {
            Fan,
            AC,
            Bulb
        }
        static void Main(string[] args)
        {
            int[] devicesCount = new int[Enum.GetValues(typeof(DeviceEnum)).Length];
            foreach (var device in Enum.GetNames(typeof(DeviceEnum)))
            {
                int index = (int)Enum.Parse(typeof(DeviceEnum), device);
                Console.Write($"Number of {device}s: ");
                devicesCount[index] = Convert.ToInt32(Console.ReadLine());
            }
            DeviceHandler dh = new DeviceHandler(new Program.DeviceEnum(), devicesCount);
            var devices = dh.GetDevices();
            
            Output op = new Output();
            
            op.ShowMenu(devices);

            while (true)
            {
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice > Device.TotalDevices)
                {
                    Console.WriteLine("InValid Selection");
                    continue;
                }

                int[] selection = dh.SelectionList[choice];

                op.ConfirmMenu(devices[selection[0]][selection[1]], selection[1]);

                if (Convert.ToInt32(Console.ReadLine()) == 1)
                {
                    dh.ChangeDeviceStatus(selection);
                }

                op.ShowMenu(devices);
            }
        }
    }
}
