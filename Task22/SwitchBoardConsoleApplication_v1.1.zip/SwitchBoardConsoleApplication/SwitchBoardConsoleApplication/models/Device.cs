﻿using System;

public class Device: DeviceModel
{
	public string DeviceName;
	private bool status = false;
	public static int TotalDevices = 0;
	public Device(string deviceName)
    {
		DeviceName = deviceName;
		TotalDevices++;
    }
	public void ChangeStatus()
    {
		status = !status;
    }
	public string GetStatus()
    {
		return (status ? "On" : "Off");
    }
}
