﻿using System;

public interface DeviceModel
{
    void ChangeStatus();
    string GetStatus();
}
