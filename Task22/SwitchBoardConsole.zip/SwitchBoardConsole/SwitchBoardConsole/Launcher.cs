﻿using SwitchBoardConsole.Views;

namespace SwitchBoardConsole
{
    class Launcher
    {
        static void Main(string[] args)
        {
            new ConsoleUI();
        }
    }
}
