﻿using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public class DeviceHandler
{
	private Device[][] devices = new Device[3][];
	private Enum _deviceEnum;
	public DeviceHandler(Enum DeviceEnum, int[] deviceCount)
	{
		_deviceEnum = DeviceEnum;
        foreach (var device in Enum.GetNames(DeviceEnum.GetType()))
        {
			int index = (int)Enum.Parse(DeviceEnum.GetType(), device);
			devices[index] = new Device[deviceCount[index]];
        }
		createDevices();
	}
	private void createDevices()
    {
		foreach (var device in Enum.GetNames(_deviceEnum.GetType()))
		{
			int index = (int)Enum.Parse(_deviceEnum.GetType(), device);
			for(var i = 0; i < devices[index].Length; i++)
            {
				devices[index][i] = new Device(device);
            }
		}
	}
	public Device[][] GetDevices()
    {
		return devices;
    }
	public void ChangeDeviceStatus(int[] choice)
    {
		devices[choice[0]][choice[1]].ChangeStatus();
    }
}
