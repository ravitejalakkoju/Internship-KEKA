﻿using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public interface DeviceConsole
{
    void ChangeStatus();
    string GetStatus();
}
