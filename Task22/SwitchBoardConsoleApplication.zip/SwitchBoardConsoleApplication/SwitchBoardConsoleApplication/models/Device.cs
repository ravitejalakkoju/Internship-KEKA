﻿using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Device: DeviceConsole
{
	public string DeviceName;
	private bool status = false;
	public static int TotalDevices = 0;
	public Device(string deviceName)
    {
		if (deviceName != "Fan" && deviceName != "AC" && deviceName != "Bulb") throw new ArgumentException("DeviceName");
		else
		{
			DeviceName = deviceName;
			TotalDevices++;
		}
    }
	public void ChangeStatus()
    {
		status = !status;
    }
	public string GetStatus()
    {
		return (status ? "On" : "Off");
    }
}
