﻿using System;

namespace SwitchBoardConsoleApplication
{
    class Program
    {
        public enum DeviceEnum
        {
            Fan,
            AC,
            Bulb
        }
        static void Main(string[] args)
        {
            int[] devicesCount = new int[3];
            foreach (var device in Enum.GetNames(typeof(DeviceEnum)))
            {
                int index = (int)Enum.Parse(typeof(DeviceEnum), device);
                devicesCount[index] = Convert.ToInt32(Console.ReadLine());
            }
            DeviceHandler dh = new DeviceHandler(new Program.DeviceEnum(), devicesCount);
            var devices = dh.GetDevices();
            
            Output op = new Output();
            
            op.ShowMenu(devices);

            while (true)
            {
                int choice = Convert.ToInt32(Console.ReadLine()) - 1;

                if (choice > Device.TotalDevices)
                {
                    Console.WriteLine("Wrong Selection");
                    continue;
                }

                int[] selection = new int[2];
                if (choice / devicesCount[0] == 0) 
                    selection = new int[2] { 0, choice };
                else if ((choice - devicesCount[0]) / devicesCount[1] == 0) 
                    selection = new int[2] { 1, choice - devicesCount[0] };
                else if ((choice - devicesCount[0] - devicesCount[1]) / devicesCount[2] == 0) 
                    selection = new int[2] { 2, choice - devicesCount[0] - devicesCount[1] };
                else Console.WriteLine("Wrong Choice");

                op.ConfirmMenu(devices[selection[0]][selection[1]], selection[1]);

                if (Convert.ToInt32(Console.ReadLine()) == 1)
                {
                    dh.ChangeDeviceStatus(selection);
                }

                op.ShowMenu(devices);
            }
        }
    }
}
