﻿namespace SwitchBoardConsoleApplication
{
    public enum Appliances
    {
        Fan,
        AC,
        Bulb
    }
}
