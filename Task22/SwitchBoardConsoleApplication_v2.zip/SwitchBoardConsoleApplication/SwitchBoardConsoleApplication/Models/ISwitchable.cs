﻿public interface ISwitchable
{
    void ChangeState();
    string GetState();
}
