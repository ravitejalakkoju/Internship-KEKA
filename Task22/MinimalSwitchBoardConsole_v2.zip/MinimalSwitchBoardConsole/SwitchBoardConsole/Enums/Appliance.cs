﻿namespace SwitchBoardConsole
{
    enum Appliance{
        Fan, 
        AC,
        Bulb
    }
}