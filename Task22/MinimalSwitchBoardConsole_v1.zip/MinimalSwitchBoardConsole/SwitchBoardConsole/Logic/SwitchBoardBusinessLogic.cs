﻿using System.Collections.Generic;
using SwitchBoardConsole.Models;

namespace SwitchBoardConsole.Logic
{
    static class SwitchBoardBusinessLogic
    {
        public static SwitchBoard CreateSwitchBoard(in Dictionary<int, int> countPerAppliance)
        {
            SwitchBoard sb = new();

            sb.CreateSwitches(countPerAppliance);

            return sb;
        }

        public static void ChangeSwitchState(Switch @switch)
        {

            @switch.State = !@switch.State;
        }
    }
}
