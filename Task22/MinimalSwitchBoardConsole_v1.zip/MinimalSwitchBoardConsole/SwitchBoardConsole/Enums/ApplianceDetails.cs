﻿using System;

namespace SwitchBoardConsole.Enums
{
    static class Appliance
    {
        private enum Appliances { 
            Fan,
            AC,
            Bulb
        };

        public static Enum AppliancesList;

        public static void GenerateMockEnum()
        {
            AppliancesList = new Appliances();
        }

        public static string GetApplianceName(int key)
        {
            return Enum.GetName(AppliancesList.GetType(), key);
        }

        public static int GetApplianceId(string name)
        {
            foreach (int key in Enum.GetValues(AppliancesList.GetType()))
            {
                if (GetApplianceName(key) == name)
                {
                    return key;
                }
            }
            return 0;
        }

        public static Array GetIds()
        {
            return Enum.GetValues(AppliancesList.GetType());
            
        }

        public static Array GetNames()
        {
            return Enum.GetNames(AppliancesList.GetType());
        }

        public static int GetApplianceCount()
        {
            return Enum.GetValues(AppliancesList.GetType()).Length;
        }
    }
}
