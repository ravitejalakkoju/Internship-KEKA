﻿using SwitchBoardConsole.Views;
using SwitchBoardConsole.Logic;
using SwitchBoardConsole.Enums;
using System.Linq;

namespace SwitchBoardConsole
{
    static class Launcher
    {
        static void Main(string[] args)
        {
            Appliance.GenerateMockEnum();

            var CountPerAppliance = SwitchBoardUI.ReadCountPerAppliance(Appliance.AppliancesList);

            var switchBoard = SwitchBoardBusinessLogic.CreateSwitchBoard(CountPerAppliance);

            while (true)
            {
                SwitchBoardUI.ShowSwitchMenu(switchBoard);

                int choice, confirmChoice;

                while (true)
                {
                        choice = SwitchBoardUI.ReadSwitchMenuChoice();

                        if (!switchBoard.Switches.Keys.Contains(choice))
                        {
                            SwitchBoardUI.ShowError(choice);
                        } 
                        else
                        {
                            while (true)
                            {
                                SwitchBoardUI.ShowConfirmMenu(switchBoard.Switches[choice]);
                                    
                                confirmChoice = SwitchBoardUI.ReadConfirmMenuChoice();

                                if (confirmChoice == 1 || confirmChoice == 2)
                                {
                                    if (confirmChoice == 1) SwitchBoardBusinessLogic.ChangeSwitchState(switchBoard.Switches[choice]);
                                    break;
                                }
                                else
                                {
                                    SwitchBoardUI.ShowError(confirmChoice);
                                }
                            }
                            break;
                        }
                }
            }
        }
    }
}
