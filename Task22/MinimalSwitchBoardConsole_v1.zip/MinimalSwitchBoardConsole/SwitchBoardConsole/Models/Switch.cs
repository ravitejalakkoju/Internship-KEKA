﻿using SwitchBoardConsole.Enums;

namespace SwitchBoardConsole.Models
{
    class Switch
    {
        public bool State { get; set; }

        public int ApplianceId { get; set; }

        public int SerialNumber { get; set; }

        public string ApplianceName { get => Appliance.GetApplianceName(ApplianceId); }

        public Switch(int applianceId, int serialNumber)
        {
            State = false;
            ApplianceId = applianceId;
            SerialNumber = serialNumber;
        }
    }
}
