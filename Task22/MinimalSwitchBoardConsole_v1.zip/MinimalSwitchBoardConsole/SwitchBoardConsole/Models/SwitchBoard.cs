﻿using System.Collections.Generic;
using System.Linq;
using System;
using SwitchBoardConsole.Enums; 

namespace SwitchBoardConsole.Models
{
    class SwitchBoard
    {
        public IDictionary<int, Switch> Switches { get; }

        public Dictionary<int, int> SwitchesPerAppliance { get; }

        public SwitchBoard()
        {
            Switches = new Dictionary<int, Switch>();

            SwitchesPerAppliance = new Dictionary<int, int>();

            foreach (var applianceId in Appliance.GetIds())
            {
                SwitchesPerAppliance.Add(Convert.ToInt32(applianceId), 0);
            }
        }

        private int GenerateSwitchKey()
        {
            return Switches.Count + 1;
        }

        public void CreateSwitch(int applianceId)
        {
            Switch @switch = new(applianceId, ++SwitchesPerAppliance[applianceId]);
            AddSwitch(@switch);
        }

        public void CreateSwitches(in Dictionary<int, int> CountPerAppliance)
        {
            foreach (int id in CountPerAppliance.Keys)
            {
                int count = CountPerAppliance[id];
                while(--count >= 0)
                {
                    CreateSwitch(id);
                }
            }
        }

        private void AddSwitch(Switch @switch)
        {
            int key = GenerateSwitchKey();
            Switches.Add(key, @switch);
        }

        public void ReplaceSwitch(int switchId, Switch @switch)
        {
            if (Switches.ContainsKey(switchId))
                Switches[switchId] = @switch;
        }

        public void RemoveSwitch(int switchKey)
        {
            Switches.Remove(switchKey);
        }

        public void RemoveSwitchForAppliance(int applianceId, int serialNumber)
        {
            int switchKey = GetSwitchKey(applianceId, serialNumber);
            Switches.Remove(switchKey);
        }

        public int GetSwitchKey(int applianceId, int serialNumber)
        {
            return Switches.Where(p => p.Value.ApplianceId == applianceId && p.Value.SerialNumber == serialNumber).Select(s => s.Key).First();
        }

        public Switch GetSwitch(int key)
        {
            return Switches[key];
        }

        public Switch GetSwitchForAppliance(int applianceId, int serialNumber)
        {
            return Switches[GetSwitchKey(applianceId, serialNumber)];
        }

        public IDictionary<int, Switch> GetSwitchesByApplianceId(int applianceId)
        {
            return (Dictionary<int, Switch>) Switches.Select(s => s).Where(p => p.Value.ApplianceId == applianceId);
        }

        public bool GetSwitchState(int key)
        {
            return Switches[key].State;
        }

        public Dictionary<int, bool> GetSwitchStates()
        {
            return Switches.ToDictionary(s => s.Key, s => s.Value.State);
        }

        public Dictionary<int, bool> GetSwitchStatesByApplianceId(int applianceId)
        {
            return Switches.Where(s => s.Value.ApplianceId == applianceId)
                            .ToDictionary(s => s.Key, s => s.Value.State);
        }

        public void OffAllSwitches()
        {
            foreach (var switchId in Switches.Keys)
            {
                Switches[switchId].State = false;
            }
        }

        public void OnAllSwitches()
        {
            foreach (var switchId in Switches.Keys)
            {
                Switches[switchId].State = true;
            }
        }
    }
}
