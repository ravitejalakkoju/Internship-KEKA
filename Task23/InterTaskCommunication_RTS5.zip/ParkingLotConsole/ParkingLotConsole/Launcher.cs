﻿using ParkingLotConsole.Views;
using ParkingLotConsole.Logic;
using ParkingLotConsole.Models;
using System;

namespace ParkingLotConsole
{
    class Launcher
    {
        static void Main(string[] args)
        {
            var parkingsPerVehicle = ParkingLotUI.ReadParkingsPerVehicle();

            var parkingLot = ParkingLotBusinessLogic.InitializeParkingLot(parkingsPerVehicle);

            while (true)
            {
                ParkingLotUI.ShowMenu();

                int choice = ParkingLotUI.ReadMenuChoice();

                switch (choice)
                {
                    case 1:
                        ParkingLotUI.ShowCurrentOccupancy(parkingLot);
                        break;
                    case 2:
                        var vehicleType = ParkingLotUI.ReadVehicleType();

                        var availability = ParkingLotBusinessLogic.CheckAvailability(vehicleType, parkingLot);

                        if (availability is not Exception)
                        {
                            var vehicleNumber = ParkingLotUI.ReadVehicleNumber((int)availability);

                            ParkingLotBusinessLogic.ParkVehicle(vehicleNumber, Convert.ToInt32(availability), parkingLot);
                        }
                        else
                        {
                            ParkingLotUI.WriteException((Exception) availability);
                        };
                        break;
                    case 3:
                        int ticketId = ParkingLotUI.ReadTicketId();
                        Object obj = ParkingLotBusinessLogic.UnParkVehicle(ticketId, parkingLot);
                        if (obj is Exception e) ParkingLotUI.WriteException(e);
                        break;
                    default:
                        break;
                }
                ParkingLotUI.GenerateLine();
            }
        }
    }
}
