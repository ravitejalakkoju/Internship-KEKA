﻿using ParkingLotConsole.Enums;

namespace ParkingLotConsole.Models
{
    class ParkingSlot
    {
        public Vehicle VehicleType { get; set; }

        public bool AvailabilityStatus { get; set; }

        public string VehicleNumber { get; set; }

        public ParkingSlot(Vehicle type)
        {
            VehicleType = type;

            AvailabilityStatus = true;

            VehicleNumber = null;
        }

        public void ChangeVehicleNumber(string vehicleNumber)
        {
            VehicleNumber = vehicleNumber;
        }

        public void ChangeVehicleType(Vehicle type)
        {
            VehicleType = type;
        }

        public void ChangeAvailabilityStatus()
        {
            AvailabilityStatus = !AvailabilityStatus;
        }
    }
}
