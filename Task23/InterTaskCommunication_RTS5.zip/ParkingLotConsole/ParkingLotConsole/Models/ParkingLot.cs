﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParkingLotConsole.Enums;

namespace ParkingLotConsole.Models
{
    class ParkingLot
    {
        public List<ParkingSlot> ParkingSlots;

        public List<Ticket> Tickets;

        public ParkingLot(in Dictionary<Vehicle, int> parkingsPerVehicle)
        {
            ParkingSlots = new();

            foreach (var vehicle in parkingsPerVehicle.Keys)
            {
                int parkings = parkingsPerVehicle[vehicle];

                while(--parkings >= 0)
                {
                    ParkingSlots.Add(new ParkingSlot(vehicle));
                }

            }

            Tickets = new();
        }

        public Object GenerateAvailableSlot(Vehicle vehicle)
        {
            try
            {
                var slotNumber = ParkingSlots.Select((ps, index) => (ps, index)).Where((s => s.ps.VehicleType == vehicle && s.ps.AvailabilityStatus)).First().index;

                return slotNumber;
            } 
            catch(InvalidOperationException e)
            {
                return e;
            }
        }

        public Ticket GenerateTicket(string vehicleNumber, int slotNumber)
        {
            int tickedId = Tickets.Count;

            return new(vehicleNumber, slotNumber, tickedId);
        }

        public void ParkVehicle(Ticket ticket)
        {
            ParkingSlots[ticket.SlotNumber].ChangeAvailabilityStatus();

            ParkingSlots[ticket.SlotNumber].ChangeVehicleNumber(ticket.VehicleNumber);

            Tickets.Add(ticket);
        }

        public void UnParkVehicle(Ticket ticket)
        {
            ticket.UpdateOutTime();

            ParkingSlots[ticket.SlotNumber].ChangeAvailabilityStatus();

            ParkingSlots[ticket.SlotNumber].ChangeVehicleNumber(null);
        }

        public Object GetTicketFromID(int id)
        {
            try
            {
                return Tickets.Where(t => t.Id == id).Select(t => t).First();
            }
            catch (Exception e)
            {
                return e;
            }
        }
    }
}
