﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParkingLotConsole.Enums;
using ParkingLotConsole.Models;

namespace ParkingLotConsole.Logic
{
    static class ParkingLotBusinessLogic
    {
        public static ParkingLot InitializeParkingLot(in Dictionary<Vehicle, int> parkingsPerVehicle)
        {
            return new ParkingLot(parkingsPerVehicle);
        }

        public static Object CheckAvailability(Vehicle type, ParkingLot parkingLot)
        {
            if (Enum.GetValues(typeof(Vehicle)).Cast<Vehicle>().Contains(type))
            {
                return parkingLot.GenerateAvailableSlot(type);
            }
            else
            {
                return new Exception("In-Valid Vehicle Type selected, Please select valid type");
            }
            
        }

        public static Ticket ParkVehicle(string vehicleNumber, int slotNumber, ParkingLot parkingLot)
        {
            Ticket ticket = parkingLot.GenerateTicket(vehicleNumber, slotNumber);

            parkingLot.ParkVehicle(ticket);

            return ticket;
        }

        public static Object UnParkVehicle(int tickedId, ParkingLot parkingLot)
        {
            Object obj = parkingLot.GetTicketFromID(tickedId);

            if(obj is Ticket ticket)
            {
                if (ticket.OutTime is null)
                {
                    parkingLot.UnParkVehicle(ticket);

                    return ticket;
                }
                else
                {
                    return new Exception("Vehicle already left");
                }
            } 
            else
            {
                return new Exception("Ticket Id doesn't exist");
            }
            
        }
    }
}
