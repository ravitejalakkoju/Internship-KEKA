﻿namespace ParkingLotConsole.Enums
{
    enum Vehicle
    {
        TwoWheeler,
        FourWheeler,
        Heavy
    }
}