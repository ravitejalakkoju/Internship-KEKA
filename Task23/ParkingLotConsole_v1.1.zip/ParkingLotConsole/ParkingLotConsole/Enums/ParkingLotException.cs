﻿namespace ParkingLotConsole.Enums
{
    enum ParkingLotException
    {
        SlotsUnavailable,
        VehicleAlreadyLeft,
        WrongChoice
    }
}