﻿namespace ParkingLotConsole.Enums
{
    enum Choice
    {
        CurrentOccupancy = 1,
        ParkVehicle,
        UnParkVehicle
    }
}